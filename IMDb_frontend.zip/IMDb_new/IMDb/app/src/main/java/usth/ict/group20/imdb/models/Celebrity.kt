package usth.ict.group20.imdb.models

data class Celebrity(
    val name: String,
    val imageUrl: String // We'll use a URL later; for now it can be a placeholder
)
