package usth.ict.group20.imdb.models

data class Celebrity(
    val name: String,
    val age: Int,
    val imageUrl: String
)
